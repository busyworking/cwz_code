#!/bin/bash
PWD=$(cd `dirname $0`;pwd)
source $PWD/venv/bin/activate
python $PWD/openfalcon.py
